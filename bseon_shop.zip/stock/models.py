from django.db import models

class Unit(models.Model):
    name = models.CharField(max_length=20, unique=True)  # Store unit names dynamically

    def __str__(self):
        return self.name

class Product(models.Model):
    name                 = models.CharField(max_length=255)
    category            = models.CharField(max_length=100, blank=True, null=True)
    supplier            = models.CharField(max_length=100, blank=True, null=True)
    price               = models.DecimalField(max_digits=10, decimal_places=2)
    #     unit = models.CharField(max_length=10, choices=UNIT_CHOICES, default='pcs')  # Added unit field

    big_unit            = models.ForeignKey(Unit, on_delete=models.SET_NULL, null=True, blank=True, related_name='big_unit_products')
    small_units_counts  = models.PositiveIntegerField(default=0)  
    small_unit          = models.ForeignKey(Unit, on_delete=models.SET_NULL, null=True, blank=True, related_name='small_unit_products')
    stock_quantity      = models.PositiveIntegerField(default=0)
    barcode             = models.CharField(max_length=50, blank=True, null=True, unique=True)

    def __str__(self):
        return f'{self.name} [ {self.get_unit_display()}]'
